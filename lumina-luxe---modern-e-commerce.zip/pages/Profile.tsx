
import React from 'react';
import { Navigate } from 'react-router-dom';
import { Package, Calendar, Tag, ArrowRight, User as UserIcon } from 'lucide-react';
import { useStore } from '../context/StoreContext';

const Profile: React.FC = () => {
  const { user, logout } = useStore();

  if (!user) return <Navigate to="/auth" />;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Sidebar Info */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm sticky top-24">
            <div className="text-center mb-8">
              <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-4 text-indigo-600">
                <UserIcon size={48} strokeWidth={1.5} />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">{user.name}</h2>
              <p className="text-gray-500 text-sm">{user.email}</p>
            </div>
            
            <div className="space-y-2">
              <button className="w-full text-left px-4 py-3 rounded-xl bg-indigo-50 text-indigo-700 font-bold transition-all">
                Order History
              </button>
              <button className="w-full text-left px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition-all">
                Shipping Addresses
              </button>
              <button className="w-full text-left px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-50 transition-all">
                Payment Methods
              </button>
              <button 
                onClick={logout}
                className="w-full text-left px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 font-medium transition-all"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>

        {/* Orders Content */}
        <div className="lg:col-span-3">
          <div className="mb-8 flex items-center justify-between">
            <h1 className="text-3xl font-extrabold text-gray-900">Your Orders</h1>
            <span className="px-3 py-1 bg-gray-100 text-gray-600 text-sm font-bold rounded-full">
              {user.orders.length} Total
            </span>
          </div>

          {user.orders.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-gray-100 shadow-sm text-center">
              <div className="w-16 h-16 bg-gray-50 text-gray-300 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900">No orders yet</h3>
              <p className="text-gray-500 mt-2">When you shop, your order details will appear here.</p>
            </div>
          ) : (
            <div className="space-y-8">
              {user.orders.map((order) => (
                <div key={order.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
                  <div className="bg-gray-50 px-8 py-4 border-b border-gray-100 flex flex-wrap justify-between items-center gap-4">
                    <div className="flex space-x-8">
                      <div>
                        <p className="text-xs uppercase font-bold text-gray-400 tracking-wider mb-1">Order ID</p>
                        <p className="font-bold text-gray-900">#{order.id}</p>
                      </div>
                      <div>
                        <p className="text-xs uppercase font-bold text-gray-400 tracking-wider mb-1">Date</p>
                        <div className="flex items-center text-gray-900 font-bold">
                          <Calendar size={14} className="mr-1.5 text-indigo-600" />
                          {order.date}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs uppercase font-bold text-gray-400 tracking-wider mb-1">Total</p>
                        <p className="font-black text-indigo-600">${order.total.toFixed(2)}</p>
                      </div>
                    </div>
                    <div>
                      <span className={`px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest ${
                        order.status === 'Processing' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-8">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center space-x-4">
                          <div className="w-16 h-16 rounded-xl bg-gray-100 flex-shrink-0">
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover rounded-xl" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-gray-800 text-sm truncate">{item.name}</h4>
                            <p className="text-gray-500 text-xs">{item.quantity} Unit{item.quantity > 1 ? 's' : ''}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-8 pt-8 border-t border-gray-100 flex justify-end">
                      <button className="text-indigo-600 font-bold flex items-center hover:text-indigo-800 transition-colors group">
                        Track Order
                        <ArrowRight size={18} className="ml-1 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
