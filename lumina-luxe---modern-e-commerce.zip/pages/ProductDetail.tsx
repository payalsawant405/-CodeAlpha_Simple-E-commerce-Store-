
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, Shield, Truck, RotateCcw, ShoppingCart, Sparkles, ChevronLeft } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { getProductInsights } from '../services/gemini';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { products, addToCart } = useStore();
  const [insight, setInsight] = useState<string>('');
  const [loadingInsight, setLoadingInsight] = useState(false);

  const product = products.find(p => p.id === id);

  useEffect(() => {
    if (product) {
      setLoadingInsight(true);
      getProductInsights(product).then(res => {
        setInsight(res);
        setLoadingInsight(false);
      });
    }
  }, [product]);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold">Product not found.</h2>
        <button onClick={() => navigate('/')} className="mt-4 text-indigo-600 font-medium hover:underline">
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <button 
        onClick={() => navigate(-1)} 
        className="flex items-center text-gray-500 hover:text-indigo-600 mb-8 transition-colors group"
      >
        <ChevronLeft size={20} className="mr-1 group-hover:-translate-x-1 transition-transform" />
        Back to shopping
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
        {/* Image Section */}
        <div className="space-y-4">
          <div className="aspect-square rounded-3xl overflow-hidden bg-gray-100 shadow-sm border border-gray-100">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-100 opacity-60 hover:opacity-100 cursor-pointer transition-opacity border border-gray-200">
                <img src={`${product.image}&sig=${i}`} alt="Thumbnail" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Content Section */}
        <div className="flex flex-col">
          <div className="mb-4">
            <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-full uppercase tracking-widest border border-indigo-100">
              {product.category}
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-4">{product.name}</h1>
          
          <div className="flex items-center space-x-4 mb-6">
            <div className="flex items-center text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={18} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} stroke="currentColor" />
              ))}
              <span className="ml-2 text-sm font-bold text-gray-700">{product.rating} / 5.0</span>
            </div>
            <span className="text-gray-300">|</span>
            <span className="text-sm text-gray-500">128 Reviews</span>
          </div>

          <p className="text-gray-600 text-lg leading-relaxed mb-8">
            {product.description}
          </p>

          <div className="text-4xl font-black text-gray-900 mb-10">
            ${product.price.toFixed(2)}
          </div>

          {/* AI Insight Box */}
          <div className="bg-gradient-to-br from-indigo-50 to-violet-50 rounded-2xl p-6 mb-10 border border-indigo-100">
            <div className="flex items-center text-indigo-600 mb-3">
              <Sparkles size={20} className="mr-2" />
              <span className="font-bold text-sm uppercase tracking-wider">AI Shopping Insight</span>
            </div>
            {loadingInsight ? (
              <div className="animate-pulse space-y-2">
                <div className="h-3 bg-indigo-200 rounded w-3/4"></div>
                <div className="h-3 bg-indigo-200 rounded w-1/2"></div>
              </div>
            ) : (
              <p className="text-indigo-900/80 italic font-medium leading-relaxed">
                "{insight}"
              </p>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <button 
              onClick={() => addToCart(product)}
              className="flex-1 bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center justify-center space-x-2 hover:bg-indigo-700 hover:shadow-lg transition-all transform hover:-translate-y-0.5"
            >
              <ShoppingCart size={20} />
              <span>Add to Cart</span>
            </button>
            <button className="flex-1 border-2 border-gray-200 text-gray-800 px-8 py-4 rounded-2xl font-bold hover:bg-gray-50 transition-colors">
              Favorite
            </button>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 border-t border-gray-100 pt-8">
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-green-50 text-green-600 rounded-lg">
                <Truck size={20} />
              </div>
              <div>
                <h4 className="font-bold text-gray-900 text-sm">Free Express Shipping</h4>
                <p className="text-gray-500 text-xs mt-1">On orders over $150. Delivery in 2-4 days.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                <RotateCcw size={20} />
              </div>
              <div>
                <h4 className="font-bold text-gray-900 text-sm">30-Day Returns</h4>
                <p className="text-gray-500 text-xs mt-1">Not happy? Send it back for a full refund.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                <Shield size={20} />
              </div>
              <div>
                <h4 className="font-bold text-gray-900 text-sm">Lifetime Warranty</h4>
                <p className="text-gray-500 text-xs mt-1">Quality guaranteed. Shop with confidence.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
