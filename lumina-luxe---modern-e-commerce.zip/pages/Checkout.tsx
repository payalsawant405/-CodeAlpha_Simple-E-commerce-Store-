
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, CheckCircle, Package, ArrowRight, ShieldCheck } from 'lucide-react';
import { useStore } from '../context/StoreContext';

const Checkout: React.FC = () => {
  const { cart, user, processOrder } = useStore();
  const navigate = useNavigate();
  const [step, setStep] = useState<'details' | 'success'>('details');

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const total = subtotal + (subtotal > 150 ? 0 : 15);

  const handlePlaceOrder = () => {
    if (!user) {
      navigate('/auth');
      return;
    }
    processOrder();
    setStep('success');
  };

  if (step === 'success') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="inline-flex items-center justify-center p-6 bg-green-50 text-green-600 rounded-full mb-8">
          <CheckCircle size={80} />
        </div>
        <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Order Confirmed!</h1>
        <p className="text-gray-500 text-xl mb-12">
          Your order has been placed successfully and is being processed by our artisan team.
        </p>
        <div className="bg-white border border-gray-100 rounded-3xl p-8 mb-12 shadow-sm text-left">
          <h3 className="font-bold text-gray-900 mb-4 flex items-center">
            <Package size={20} className="mr-2 text-indigo-600" />
            Next Steps
          </h3>
          <ul className="space-y-3 text-gray-600">
            <li className="flex items-center">
              <span className="w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold mr-3">1</span>
              Confirmation email sent to {user?.email}
            </li>
            <li className="flex items-center">
              <span className="w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold mr-3">2</span>
              Items packed with eco-friendly materials
            </li>
            <li className="flex items-center">
              <span className="w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold mr-3">3</span>
              Shipping notification with tracking ID incoming
            </li>
          </ul>
        </div>
        <button 
          onClick={() => navigate('/')}
          className="bg-indigo-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg"
        >
          Continue Shopping
        </button>
      </div>
    );
  }

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-extrabold text-gray-900 mb-10">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Forms */}
        <div className="space-y-10">
          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm mr-3">1</span>
              Shipping Information
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input type="text" placeholder="First Name" className="p-4 rounded-xl border border-gray-200 w-full" />
              <input type="text" placeholder="Last Name" className="p-4 rounded-xl border border-gray-200 w-full" />
              <input type="text" placeholder="Address" className="p-4 rounded-xl border border-gray-200 w-full sm:col-span-2" />
              <input type="text" placeholder="City" className="p-4 rounded-xl border border-gray-200 w-full" />
              <input type="text" placeholder="Zip Code" className="p-4 rounded-xl border border-gray-200 w-full" />
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <span className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm mr-3">2</span>
              Payment Details
            </h2>
            <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100 space-y-4">
              <div className="flex items-center justify-between mb-4">
                <CreditCard className="text-indigo-600" />
                <div className="flex space-x-2">
                  <div className="w-8 h-5 bg-gray-300 rounded"></div>
                  <div className="w-8 h-5 bg-gray-300 rounded"></div>
                </div>
              </div>
              <input type="text" placeholder="Card Number" className="p-4 rounded-xl border border-gray-200 w-full bg-white" />
              <div className="grid grid-cols-2 gap-4">
                <input type="text" placeholder="MM/YY" className="p-4 rounded-xl border border-gray-200 w-full bg-white" />
                <input type="text" placeholder="CVV" className="p-4 rounded-xl border border-gray-200 w-full bg-white" />
              </div>
            </div>
          </section>
        </div>

        {/* Sticky Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm sticky top-24">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Review Order</h2>
            <div className="max-h-[300px] overflow-y-auto pr-2 mb-6 space-y-4">
              {cart.map(item => (
                <div key={item.id} className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-xl bg-gray-50 flex-shrink-0">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover rounded-xl" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-800 text-sm line-clamp-1">{item.name}</h4>
                    <p className="text-gray-500 text-xs">{item.quantity} × ${item.price}</p>
                  </div>
                  <span className="font-bold text-gray-900">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            
            <div className="space-y-3 pt-6 border-t border-gray-100 mb-8">
              <div className="flex justify-between text-gray-600 text-sm">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600 text-sm">
                <span>Shipping</span>
                <span>{subtotal > 150 ? 'FREE' : '$15.00'}</span>
              </div>
              <div className="flex justify-between items-center text-xl font-black text-gray-900 pt-2">
                <span>Total</span>
                <span className="text-indigo-600">${total.toFixed(2)}</span>
              </div>
            </div>

            <button 
              onClick={handlePlaceOrder}
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center space-x-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              <span>Place Order</span>
              <ArrowRight size={20} />
            </button>

            <div className="flex items-center justify-center mt-6 text-gray-400 space-x-2">
              <ShieldCheck size={16} />
              <span className="text-xs">Secure SSL Payment Guaranteed</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
