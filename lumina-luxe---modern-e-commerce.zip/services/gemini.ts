
import { GoogleGenAI } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getProductInsights = async (product: Product): Promise<string> => {
  if (!process.env.API_KEY) return "AI insights are unavailable without an API Key.";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a shopping assistant. Provide a short, persuasive 2-sentence reason why someone should buy the "${product.name}". Focus on its category "${product.category}" and features: "${product.description}".`,
    });
    return response.text || "This is a great choice for your needs.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Our AI assistant is currently recharging. This product is highly rated by our community!";
  }
};
